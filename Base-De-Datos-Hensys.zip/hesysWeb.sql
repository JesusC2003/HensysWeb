CREATE DATABASE  IF NOT EXISTS `hensys` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `hensys`;
-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: hensys
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ajuste_inventario`
--

DROP TABLE IF EXISTS `ajuste_inventario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ajuste_inventario` (
  `IdAjuste` int NOT NULL AUTO_INCREMENT,
  `IdProducto` int DEFAULT NULL,
  `TipoAjuste` enum('Pérdida','AjusteManual') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Cantidad` decimal(10,2) DEFAULT NULL,
  `Fecha` date DEFAULT NULL,
  `Motivo` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`IdAjuste`),
  KEY `IdProducto` (`IdProducto`),
  CONSTRAINT `ajuste_inventario_ibfk_1` FOREIGN KEY (`IdProducto`) REFERENCES `producto` (`IdProducto`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ajuste_inventario`
--

LOCK TABLES `ajuste_inventario` WRITE;
/*!40000 ALTER TABLE `ajuste_inventario` DISABLE KEYS */;
INSERT INTO `ajuste_inventario` VALUES (1,1,'Pérdida',3.00,'2025-05-01','Huevos rotos durante el transporte'),(2,2,'AjusteManual',5.00,'2025-05-02','Reconteo físico del inventario'),(3,3,'Pérdida',1.50,'2025-05-03','Carne en mal estado'),(4,4,'Pérdida',2.00,'2025-05-04','Gallina enferma retirada'),(5,5,'AjusteManual',10.00,'2025-05-05','Error en el sistema de registro'),(6,1,'AjusteManual',4.00,'2025-05-06','Revisión por auditoría'),(7,2,'Pérdida',6.00,'2025-05-07','Huevos dañados por temperatura'),(8,3,'AjusteManual',2.50,'2025-05-08','Diferencia por despacho manual'),(9,4,'Pérdida',3.00,'2025-05-09','Gallina muerta por ataque de animal'),(10,5,'AjusteManual',5.00,'2025-05-10','Inventario actualizado por nuevo lote'),(11,1,'Pérdida',2.00,'2025-05-11','Huevos rotos por manejo incorrecto'),(12,2,'AjusteManual',3.00,'2025-05-12','Revisión mensual de inventario'),(13,3,'Pérdida',1.00,'2025-05-13','Descomposición por falta de refrigeración'),(14,4,'Pérdida',2.00,'2025-05-14','Gallina sacrificada por enfermedad'),(15,5,'AjusteManual',8.00,'2025-05-15','Corrección tras auditoría'),(16,1,'AjusteManual',1.00,'2025-05-16','Verificación por sistema nuevo'),(17,2,'Pérdida',4.00,'2025-05-17','Huevos rotos durante empaque'),(18,3,'AjusteManual',3.50,'2025-05-18','Reajuste tras balanceo'),(19,4,'Pérdida',1.50,'2025-05-19','Gallina extraviada'),(20,5,'AjusteManual',6.00,'2025-05-20','Sincronización con inventario digital');
/*!40000 ALTER TABLE `ajuste_inventario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `animal`
--

DROP TABLE IF EXISTS `animal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `animal` (
  `IdAnimal` int NOT NULL AUTO_INCREMENT,
  `Tipo` enum('Gallina','Pollo','Otro') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Gallina',
  `EdadSemanas` int DEFAULT NULL,
  `PesoPromedio` decimal(5,2) DEFAULT NULL,
  `IdLote` int DEFAULT NULL,
  PRIMARY KEY (`IdAnimal`),
  KEY `IdLote` (`IdLote`),
  CONSTRAINT `animal_ibfk_1` FOREIGN KEY (`IdLote`) REFERENCES `lote_animal` (`IdLote`)
) ENGINE=InnoDB AUTO_INCREMENT=291 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `animal`
--

LOCK TABLES `animal` WRITE;
/*!40000 ALTER TABLE `animal` DISABLE KEYS */;
INSERT INTO `animal` VALUES (1,'Gallina',30,1.80,1),(2,'Pollo',6,1.20,2),(3,'Gallina',28,1.75,3),(4,'Gallina',32,1.85,4),(5,'Pollo',5,1.10,5),(6,'Otro',12,2.00,6),(7,'Gallina',26,1.70,7),(8,'Pollo',7,1.30,8),(9,'Gallina',29,1.78,9),(10,'Pollo',4,1.00,10),(11,'Gallina',31,1.82,11),(12,'Gallina',33,1.90,12),(13,'Pollo',8,1.35,13),(14,'Gallina',27,1.76,14),(15,'Otro',10,1.95,15),(16,'Pollo',6,1.22,16),(17,'Gallina',30,1.80,17),(18,'Gallina',34,1.88,18),(19,'Pollo',5,1.15,19),(20,'Otro',9,1.98,20),(21,'Gallina',30,1.80,1),(22,'Gallina',31,1.82,1),(23,'Gallina',32,1.85,1),(24,'Gallina',29,1.75,1),(25,'Gallina',28,1.70,1),(26,'Gallina',30,1.78,1),(27,'Gallina',31,1.81,1),(28,'Gallina',30,1.79,1),(29,'Gallina',32,1.83,1),(30,'Gallina',31,1.80,1),(31,'Gallina',29,1.76,1),(32,'Gallina',30,1.77,1),(33,'Gallina',30,1.80,1),(34,'Gallina',31,1.84,1),(35,'Gallina',32,1.86,1),(36,'Gallina',28,1.72,1),(37,'Gallina',29,1.74,1),(38,'Gallina',30,1.79,1),(39,'Gallina',31,1.82,1),(40,'Gallina',32,1.85,1),(41,'Pollo',6,1.20,2),(42,'Pollo',7,1.25,2),(43,'Pollo',5,1.10,2),(44,'Pollo',6,1.22,2),(45,'Pollo',6,1.23,2),(46,'Pollo',7,1.28,2),(47,'Pollo',5,1.15,2),(48,'Pollo',6,1.18,2),(49,'Pollo',7,1.26,2),(50,'Pollo',6,1.21,2),(51,'Pollo',5,1.14,2),(52,'Pollo',6,1.19,2),(53,'Pollo',6,1.20,2),(54,'Pollo',7,1.27,2),(55,'Pollo',5,1.11,2),(56,'Pollo',6,1.22,2),(57,'Pollo',6,1.24,2),(58,'Pollo',7,1.29,2),(59,'Pollo',5,1.12,2),(60,'Pollo',6,1.20,2),(61,'Gallina',28,1.76,3),(62,'Gallina',27,1.74,3),(63,'Gallina',29,1.78,3),(64,'Gallina',30,1.80,3),(65,'Gallina',28,1.77,3),(66,'Gallina',29,1.79,3),(67,'Gallina',30,1.81,3),(68,'Gallina',28,1.75,3),(69,'Gallina',27,1.73,3),(70,'Gallina',29,1.76,3),(71,'Gallina',28,1.78,3),(72,'Gallina',30,1.82,3),(73,'Gallina',27,1.72,3),(74,'Gallina',28,1.74,3),(75,'Gallina',29,1.79,3),(76,'Gallina',30,1.83,3),(77,'Gallina',27,1.71,3),(78,'Gallina',28,1.75,3),(79,'Gallina',29,1.77,3),(80,'Gallina',30,1.84,3),(81,'Gallina',32,1.85,4),(82,'Gallina',31,1.83,4),(83,'Gallina',33,1.87,4),(84,'Gallina',32,1.86,4),(85,'Gallina',31,1.84,4),(86,'Gallina',33,1.88,4),(87,'Gallina',32,1.85,4),(88,'Gallina',31,1.83,4),(89,'Gallina',32,1.86,4),(90,'Gallina',33,1.87,4),(91,'Gallina',32,1.84,4),(92,'Gallina',31,1.82,4),(93,'Gallina',32,1.85,4),(94,'Gallina',33,1.88,4),(95,'Gallina',31,1.81,4),(96,'Gallina',32,1.83,4),(97,'Gallina',33,1.87,4),(98,'Gallina',32,1.86,4),(99,'Gallina',31,1.82,4),(100,'Gallina',32,1.85,4),(101,'Pollo',5,1.15,5),(102,'Pollo',6,1.20,5),(103,'Pollo',7,1.25,5),(104,'Pollo',5,1.10,5),(105,'Pollo',6,1.18,5),(106,'Pollo',6,1.22,5),(107,'Pollo',5,1.14,5),(108,'Pollo',7,1.27,5),(109,'Pollo',6,1.23,5),(110,'Pollo',6,1.21,5),(111,'Pollo',5,1.13,5),(112,'Pollo',6,1.20,5),(113,'Pollo',7,1.28,5),(114,'Pollo',5,1.11,5),(115,'Pollo',6,1.24,5),(116,'Pollo',5,1.12,5),(117,'Pollo',6,1.19,5),(118,'Pollo',7,1.26,5),(119,'Pollo',6,1.20,5),(120,'Pollo',5,1.10,5),(121,'Gallina',30,1.85,6),(122,'Gallina',31,1.87,6),(123,'Gallina',29,1.82,6),(124,'Gallina',28,1.78,6),(125,'Gallina',30,1.80,6),(126,'Gallina',32,1.90,6),(127,'Gallina',31,1.88,6),(128,'Gallina',29,1.81,6),(129,'Gallina',30,1.83,6),(130,'Gallina',28,1.76,6),(131,'Gallina',31,1.85,6),(132,'Gallina',30,1.84,6),(133,'Gallina',29,1.79,6),(134,'Gallina',32,1.91,6),(135,'Gallina',31,1.86,6),(136,'Gallina',30,1.82,6),(137,'Gallina',29,1.80,6),(138,'Gallina',28,1.75,6),(139,'Gallina',30,1.83,6),(140,'Gallina',32,1.89,6),(141,'Pollo',6,1.15,7),(142,'Pollo',5,1.12,7),(143,'Pollo',7,1.18,7),(144,'Pollo',6,1.14,7),(145,'Pollo',6,1.16,7),(146,'Pollo',5,1.11,7),(147,'Pollo',6,1.15,7),(148,'Pollo',7,1.19,7),(149,'Pollo',5,1.10,7),(150,'Pollo',6,1.13,7),(151,'Pollo',7,1.20,7),(152,'Pollo',6,1.17,7),(153,'Pollo',5,1.09,7),(154,'Pollo',6,1.14,7),(155,'Pollo',6,1.15,7),(156,'Pollo',7,1.18,7),(157,'Pollo',5,1.10,7),(158,'Pollo',6,1.13,7),(159,'Pollo',6,1.16,7),(160,'Pollo',7,1.19,7),(161,'Gallina',29,1.78,8),(162,'Gallina',30,1.80,8),(163,'Gallina',28,1.76,8),(164,'Gallina',29,1.79,8),(165,'Gallina',30,1.81,8),(166,'Gallina',31,1.83,8),(167,'Gallina',30,1.82,8),(168,'Gallina',29,1.78,8),(169,'Gallina',28,1.75,8),(170,'Gallina',30,1.80,8),(171,'Gallina',29,1.77,8),(172,'Gallina',28,1.74,8),(173,'Gallina',30,1.82,8),(174,'Gallina',31,1.85,8),(175,'Gallina',30,1.83,8),(176,'Gallina',29,1.81,8),(177,'Gallina',28,1.76,8),(178,'Gallina',30,1.80,8),(179,'Gallina',31,1.84,8),(180,'Gallina',29,1.79,8),(181,'Pollo',6,1.12,9),(182,'Pollo',5,1.10,9),(183,'Pollo',7,1.18,9),(184,'Pollo',6,1.14,9),(185,'Pollo',6,1.16,9),(186,'Pollo',5,1.11,9),(187,'Pollo',6,1.13,9),(188,'Pollo',7,1.17,9),(189,'Pollo',5,1.09,9),(190,'Pollo',6,1.12,9),(191,'Pollo',7,1.19,9),(192,'Pollo',6,1.15,9),(193,'Pollo',5,1.08,9),(194,'Pollo',6,1.14,9),(195,'Pollo',6,1.13,9),(196,'Pollo',7,1.17,9),(197,'Pollo',5,1.09,9),(198,'Pollo',6,1.11,9),(199,'Pollo',6,1.13,9),(200,'Pollo',7,1.16,9),(201,'Gallina',32,1.87,10),(202,'Gallina',31,1.85,10),(203,'Gallina',30,1.83,10),(204,'Gallina',29,1.80,10),(205,'Gallina',32,1.88,10),(206,'Gallina',30,1.82,10),(207,'Gallina',29,1.79,10),(208,'Gallina',31,1.84,10),(209,'Gallina',32,1.87,10),(210,'Gallina',30,1.81,10),(211,'Gallina',29,1.78,10),(212,'Gallina',30,1.83,10),(213,'Gallina',31,1.85,10),(214,'Gallina',32,1.86,10),(215,'Gallina',29,1.77,10),(216,'Gallina',30,1.80,10),(217,'Gallina',31,1.82,10),(218,'Gallina',32,1.85,10),(219,'Gallina',30,1.81,10),(220,'Gallina',29,1.76,10),(221,'Gallina',30,1.83,10),(222,'Gallina',31,1.85,10),(223,'Gallina',29,1.80,10),(224,'Gallina',30,1.82,10),(225,'Gallina',28,1.78,10),(226,'Gallina',32,1.87,10),(227,'Gallina',31,1.84,10),(228,'Gallina',30,1.81,10),(229,'Gallina',29,1.79,10),(230,'Gallina',28,1.77,10),(231,'Pollo',6,1.14,11),(232,'Pollo',5,1.10,11),(233,'Pollo',6,1.13,11),(234,'Pollo',7,1.16,11),(235,'Pollo',6,1.15,11),(236,'Pollo',5,1.09,11),(237,'Pollo',6,1.12,11),(238,'Pollo',6,1.11,11),(239,'Pollo',7,1.17,11),(240,'Pollo',6,1.13,11),(241,'Gallina',30,1.84,12),(242,'Gallina',29,1.81,12),(243,'Gallina',31,1.86,12),(244,'Gallina',30,1.83,12),(245,'Gallina',28,1.79,12),(246,'Gallina',32,1.88,12),(247,'Gallina',31,1.85,12),(248,'Gallina',30,1.82,12),(249,'Gallina',29,1.80,12),(250,'Gallina',28,1.78,12),(251,'Pollo',6,1.12,13),(252,'Pollo',5,1.08,13),(253,'Pollo',6,1.14,13),(254,'Pollo',7,1.16,13),(255,'Pollo',6,1.13,13),(256,'Pollo',5,1.10,13),(257,'Pollo',6,1.11,13),(258,'Pollo',6,1.13,13),(259,'Pollo',7,1.15,13),(260,'Pollo',6,1.12,13),(261,'Gallina',31,1.86,14),(262,'Gallina',30,1.83,14),(263,'Gallina',29,1.80,14),(264,'Gallina',30,1.82,14),(265,'Gallina',28,1.78,14),(266,'Gallina',32,1.89,14),(267,'Gallina',31,1.85,14),(268,'Gallina',30,1.81,14),(269,'Gallina',29,1.79,14),(270,'Gallina',28,1.77,14),(271,'Pollo',6,1.15,15),(272,'Pollo',5,1.09,15),(273,'Pollo',6,1.13,15),(274,'Pollo',7,1.18,15),(275,'Pollo',6,1.14,15),(276,'Pollo',5,1.10,15),(277,'Pollo',6,1.12,15),(278,'Pollo',6,1.13,15),(279,'Pollo',7,1.17,15),(280,'Pollo',6,1.14,15),(281,'Gallina',30,1.85,16),(282,'Gallina',29,1.82,16),(283,'Gallina',31,1.86,16),(284,'Gallina',30,1.83,16),(285,'Gallina',28,1.80,16),(286,'Gallina',32,1.88,16),(287,'Gallina',31,1.84,16),(288,'Gallina',30,1.82,16),(289,'Gallina',29,1.81,16),(290,'Gallina',28,1.78,16);
/*!40000 ALTER TABLE `animal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cliente`
--

DROP TABLE IF EXISTS `cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cliente` (
  `IdCliente` int NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Telefono` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Direccion` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Tipo` enum('Natural','Jurídico') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Natural',
  PRIMARY KEY (`IdCliente`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente`
--

LOCK TABLES `cliente` WRITE;
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
INSERT INTO `cliente` VALUES (1,'Carlos Méndez','3124567890','cmendez@example.com','Calle 45 #12-34','Natural'),(2,'Granja Avícola El Progreso','3176543210','contacto@elprogreso.com','Vereda Las Palmas','Jurídico'),(3,'María Fernanda Ruiz','3109876543','maria.ruiz@example.com','Carrera 10 #5-67','Natural'),(4,'Distribuciones Avícolas S.A.','3204567891','ventas@distribav.com','Zona Industrial Bodega 4','Jurídico'),(5,'Juan Camilo Ríos','3001122334','jc.rios@example.com','Calle 23 #8-90','Natural'),(6,'Avícola San Jorge Ltda.','3182223344','info@sanjorge.com','Km 7 vía al norte','Jurídico'),(7,'Ana Torres','3013344556','ana.torres@example.com','Carrera 8 #22-45','Natural'),(8,'Avícolas Integradas SAS','3199876543','contacto@avintegradas.com','Av. Central 300','Jurídico'),(9,'Luis Alberto Mendoza','3044455667','luis.mendoza@example.com','Calle 50 #10-10','Natural'),(10,'Pollos del Sur S.A.S.','3165566778','pollossur@empresa.com','Parque Industrial Galpón 6','Jurídico'),(11,'Camila Zapata','3026677889','camila.zapata@example.com','Carrera 12 #45-78','Natural'),(12,'Grupo Avícola Nacional','3217788990','grupo@avicola.co','Zona Franca, lote 3','Jurídico'),(13,'Eduardo López','3038899001','eduardo.lopez@example.com','Calle 9 #7-65','Natural'),(14,'Agropecuaria del Norte','3149900112','agronorte@correo.com','Finca Las Margaritas','Jurídico'),(15,'Natalia Herrera','3112233445','natalia.herrera@example.com','Carrera 15 #34-12','Natural');
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalle_factura`
--

DROP TABLE IF EXISTS `detalle_factura`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detalle_factura` (
  `IdDetalle` int NOT NULL AUTO_INCREMENT,
  `IdFactura` int NOT NULL,
  `IdProducto` int NOT NULL,
  `Cantidad` decimal(10,2) NOT NULL,
  `PrecioUnitario` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`IdDetalle`),
  KEY `detalle_factura_ibfk_1` (`IdFactura`),
  KEY `detalle_factura_ibfk_2` (`IdProducto`),
  CONSTRAINT `detalle_factura_ibfk_1` FOREIGN KEY (`IdFactura`) REFERENCES `factura` (`IdFactura`),
  CONSTRAINT `detalle_factura_ibfk_2` FOREIGN KEY (`IdProducto`) REFERENCES `producto` (`IdProducto`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_factura`
--

LOCK TABLES `detalle_factura` WRITE;
/*!40000 ALTER TABLE `detalle_factura` DISABLE KEYS */;
INSERT INTO `detalle_factura` VALUES (1,1,1,10.00,5.00,'2025-06-01 23:01:16','2025-06-01 23:01:16'),(2,1,2,2.00,20.00,'2025-06-01 23:01:16','2025-06-01 23:01:16'),(3,1,3,1.00,50.00,'2025-06-01 23:01:16','2025-06-01 23:01:16'),(4,2,1,5.00,5.00,'2025-06-01 23:01:16','2025-06-01 23:01:16'),(5,2,4,10.00,15.00,'2025-06-01 23:01:16','2025-06-01 23:01:16'),(6,3,3,3.00,50.00,'2025-06-01 23:01:16','2025-06-01 23:01:16'),(7,3,5,7.00,7.25,'2025-06-01 23:01:16','2025-06-01 23:01:16'),(8,3,2,1.00,20.00,'2025-06-01 23:01:16','2025-06-01 23:01:16'),(9,3,1,2.00,5.00,'2025-06-01 23:01:16','2025-06-01 23:01:16'),(10,4,4,8.00,15.00,'2025-06-01 23:01:16','2025-06-01 23:01:16'),(11,4,1,4.00,5.00,'2025-06-01 23:01:16','2025-06-01 23:01:16'),(12,5,5,20.00,7.25,'2025-06-01 23:01:16','2025-06-01 23:01:16'),(13,5,3,1.00,50.00,'2025-06-01 23:01:16','2025-06-01 23:01:16'),(14,5,2,2.00,20.00,'2025-06-01 23:01:16','2025-06-01 23:01:16'),(15,6,1,6.00,5.00,'2025-06-01 23:01:16','2025-06-01 23:01:16'),(16,6,4,5.00,15.00,'2025-06-01 23:01:16','2025-06-01 23:01:16'),(17,6,5,3.00,7.25,'2025-06-01 23:01:16','2025-06-01 23:01:16'),(18,7,2,2.00,20.00,'2025-06-01 23:01:16','2025-06-01 23:01:16'),(19,7,3,1.00,50.00,'2025-06-01 23:01:16','2025-06-01 23:01:16'),(20,8,4,10.00,15.00,'2025-06-01 23:01:16','2025-06-01 23:01:16'),(21,8,1,5.00,5.00,'2025-06-01 23:01:16','2025-06-01 23:01:16'),(22,8,2,1.00,20.00,'2025-06-01 23:01:16','2025-06-01 23:01:16'),(23,9,5,15.00,7.25,'2025-06-01 23:01:16','2025-06-01 23:01:16'),(24,9,3,2.00,50.00,'2025-06-01 23:01:16','2025-06-01 23:01:16'),(25,9,1,3.00,5.00,'2025-06-01 23:01:16','2025-06-01 23:01:16'),(26,10,2,4.00,20.00,'2025-06-01 23:01:16','2025-06-01 23:01:16'),(27,10,4,6.00,15.00,'2025-06-01 23:01:16','2025-06-01 23:01:16'),(28,10,5,1.00,7.25,'2025-06-01 23:01:16','2025-06-01 23:01:16');
/*!40000 ALTER TABLE `detalle_factura` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `factura`
--

DROP TABLE IF EXISTS `factura`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `factura` (
  `IdFactura` int NOT NULL AUTO_INCREMENT,
  `Fecha` date DEFAULT NULL,
  `IdCliente` int NOT NULL,
  `Total` decimal(10,2) DEFAULT NULL,
  `IdUsuario` int NOT NULL,
  PRIMARY KEY (`IdFactura`),
  KEY `factura_ibfk_1` (`IdCliente`),
  KEY `fk_factura_usuario` (`IdUsuario`),
  CONSTRAINT `factura_ibfk_1` FOREIGN KEY (`IdCliente`) REFERENCES `cliente` (`IdCliente`),
  CONSTRAINT `fk_factura_usuario` FOREIGN KEY (`IdUsuario`) REFERENCES `usuario` (`IdUsuario`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `factura`
--

LOCK TABLES `factura` WRITE;
/*!40000 ALTER TABLE `factura` DISABLE KEYS */;
INSERT INTO `factura` VALUES (1,'2025-05-15',1,150.00,1),(2,'2025-05-16',3,275.50,2),(3,'2025-05-17',5,80.75,1),(4,'2025-05-18',2,120.00,3),(5,'2025-05-19',7,300.00,4),(6,'2025-05-20',9,450.25,2),(7,'2025-05-21',4,210.10,1),(8,'2025-05-22',6,99.99,5),(9,'2025-05-23',11,175.00,3),(10,'2025-05-24',8,250.00,4);
/*!40000 ALTER TABLE `factura` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `galpon`
--

DROP TABLE IF EXISTS `galpon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `galpon` (
  `IdGalpon` int NOT NULL AUTO_INCREMENT,
  `Numero` int NOT NULL,
  `Tipo` enum('Ponedoras','Engorde','Reproductoras') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Ponedoras',
  `CapacidadMax` int NOT NULL,
  `Estado` enum('Activo','Inactivo','Mantenimiento') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Activo',
  `Observaciones` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_Granja` int NOT NULL,
  PRIMARY KEY (`IdGalpon`),
  KEY `galpon_ibfk_1` (`id_Granja`),
  CONSTRAINT `galpon_ibfk_1` FOREIGN KEY (`id_Granja`) REFERENCES `granja` (`IdGranja`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `galpon`
--

LOCK TABLES `galpon` WRITE;
/*!40000 ALTER TABLE `galpon` DISABLE KEYS */;
INSERT INTO `galpon` VALUES (1,1,'Ponedoras',1000,'Activo','Galpón principal para producción de huevos',1),(2,2,'Engorde',800,'Activo','Pollos de engorde ciclo 1',2),(3,3,'Ponedoras',1200,'Mantenimiento','Cambio de techado en proceso',1),(4,4,'Reproductoras',900,'Activo','Área destinada a reproductoras seleccionadas',3),(5,5,'Engorde',700,'Inactivo','Desinfección pendiente',1),(6,6,'Ponedoras',950,'Activo','Nuevo galpón operativo desde marzo',4),(7,7,'Reproductoras',850,'Activo','Condiciones óptimas de humedad',2),(8,8,'Engorde',750,'Mantenimiento','Reparación de sistema eléctrico',2),(9,9,'Ponedoras',1100,'Activo','Producción estable de huevos marrones',5),(10,10,'Ponedoras',1000,'Activo','Sin observaciones',3),(11,11,'Engorde',850,'Activo','Turno 2 de ciclo de engorde',4),(12,12,'Reproductoras',920,'Inactivo','Vacío sanitario en progreso',1),(13,13,'Ponedoras',990,'Activo','Incluye nuevo sistema de ventilación',2),(14,14,'Engorde',780,'Activo','Lote de prueba con nueva alimentación',3),(15,15,'Reproductoras',870,'Mantenimiento','Fumigación programada',5),(16,16,'Ponedoras',1050,'Activo','Alta productividad reportada',4),(17,17,'Engorde',800,'Inactivo','Aislado por brote de enfermedad',1),(18,18,'Reproductoras',940,'Activo','Área con nueva genética',2),(19,19,'Ponedoras',1020,'Activo','Producción para exportación',5),(20,20,'Engorde',700,'Activo','Ciclo listo para cosecha',3);
/*!40000 ALTER TABLE `galpon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gasto`
--

DROP TABLE IF EXISTS `gasto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gasto` (
  `IdGasto` int NOT NULL AUTO_INCREMENT,
  `Categoria` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Monto` decimal(10,2) DEFAULT NULL,
  `Fecha` date DEFAULT NULL,
  `Descripcion` text COLLATE utf8mb4_unicode_ci,
  `Responsable` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `IdGranja` int NOT NULL,
  PRIMARY KEY (`IdGasto`),
  KEY `IdGranja` (`IdGranja`),
  CONSTRAINT `gasto_ibfk_1` FOREIGN KEY (`IdGranja`) REFERENCES `granja` (`IdGranja`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gasto`
--

LOCK TABLES `gasto` WRITE;
/*!40000 ALTER TABLE `gasto` DISABLE KEYS */;
INSERT INTO `gasto` VALUES (1,'Alimentación',150000.00,'2025-05-01','Compra de concentrado para aves','Lina Gómez',1),(2,'Mantenimiento',50000.00,'2025-05-03','Reparación de techos en galpón 3','Carlos Díaz',2),(3,'Salud Animal',85000.00,'2025-05-04','Vacunación de aves contra Newcastle','Dra. Andrea Ruiz',3),(4,'Servicios Públicos',32000.00,'2025-05-05','Pago de energía eléctrica','Juan Pérez',4),(5,'Bioseguridad',25000.00,'2025-05-06','Compra de insumos de limpieza y desinfección','Marta Suárez',5),(6,'Alimentación',145000.00,'2025-05-07','Compra adicional de maíz molido','Lina Gómez',1),(7,'Salud Animal',92000.00,'2025-05-08','Medicamentos para aves enfermas','Dra. Andrea Ruiz',2),(8,'Mantenimiento',60000.00,'2025-05-10','Cambio de mallas en galpones','Carlos Díaz',3),(9,'Servicios Públicos',35000.00,'2025-05-12','Factura de agua potable','Juan Pérez',4),(10,'Alimentación',170000.00,'2025-05-13','Compra de alimento balanceado premium','Marta Suárez',5);
/*!40000 ALTER TABLE `gasto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `granja`
--

DROP TABLE IF EXISTS `granja`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `granja` (
  `IdGranja` int NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `NIT` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Ubicacion` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`IdGranja`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `granja`
--

LOCK TABLES `granja` WRITE;
/*!40000 ALTER TABLE `granja` DISABLE KEYS */;
INSERT INTO `granja` VALUES (1,'Granja El Prado','9001234567','Vereda La Esperanza, Valledupar, Cesar'),(2,'Granja San Antonio','9007654321','Corregimiento de Azúcar Buena, Codazzi, Cesar'),(3,'Granja Los Álamos','9012345678','Km 12 vía Bosconia, Cesar'),(4,'Granja Santa María','9018765432','Finca La Bendición, La Paz, Cesar'),(5,'Granja El Descanso','9023456789','Zona rural de Manaure, Cesar');
/*!40000 ALTER TABLE `granja` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventario`
--

DROP TABLE IF EXISTS `inventario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventario` (
  `IdInventario` int NOT NULL AUTO_INCREMENT,
  `IdProducto` int NOT NULL,
  `CantidadDisponible` decimal(10,2) DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`IdInventario`),
  KEY `inventario_ibfk_1` (`IdProducto`),
  CONSTRAINT `inventario_ibfk_1` FOREIGN KEY (`IdProducto`) REFERENCES `producto` (`IdProducto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventario`
--

LOCK TABLES `inventario` WRITE;
/*!40000 ALTER TABLE `inventario` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lote_animal`
--

DROP TABLE IF EXISTS `lote_animal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lote_animal` (
  `IdLote` int NOT NULL AUTO_INCREMENT,
  `NombreLote` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `FechaIngreso` date NOT NULL,
  `IdGalpon` int NOT NULL,
  PRIMARY KEY (`IdLote`),
  KEY `lote_animal_ibfk_1` (`IdGalpon`),
  CONSTRAINT `lote_animal_ibfk_1` FOREIGN KEY (`IdGalpon`) REFERENCES `galpon` (`IdGalpon`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lote_animal`
--

LOCK TABLES `lote_animal` WRITE;
/*!40000 ALTER TABLE `lote_animal` DISABLE KEYS */;
INSERT INTO `lote_animal` VALUES (1,'L001','2025-04-01',1),(2,'L002','2025-04-05',2),(3,'L003','2025-04-07',3),(4,'L004','2025-04-10',4),(5,'L005','2025-04-12',5),(6,'L006','2025-04-14',1),(7,'L007','2025-04-16',2),(8,'L008','2025-04-18',3),(9,'L009','2025-04-20',4),(10,'L010','2025-04-22',5),(11,'L011','2025-04-24',1),(12,'L012','2025-04-26',2),(13,'L013','2025-04-28',3),(14,'L014','2025-04-30',4),(15,'L015','2025-05-02',5),(16,'L016','2025-05-04',1),(17,'L017','2025-05-06',2),(18,'L018','2025-05-08',3),(19,'L019','2025-05-10',4),(20,'L020','2025-05-12',5);
/*!40000 ALTER TABLE `lote_animal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `produccion`
--

DROP TABLE IF EXISTS `produccion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `produccion` (
  `IdProduccion` int NOT NULL AUTO_INCREMENT,
  `Fecha` date NOT NULL,
  `IdGalpon` int NOT NULL,
  `IdProducto` int NOT NULL,
  `CantidadProduccion` decimal(10,2) NOT NULL,
  `Observaciones` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`IdProduccion`),
  KEY `produccion_ibfk_1` (`IdGalpon`),
  KEY `produccion_ibfk_2` (`IdProducto`),
  CONSTRAINT `produccion_ibfk_1` FOREIGN KEY (`IdGalpon`) REFERENCES `galpon` (`IdGalpon`),
  CONSTRAINT `produccion_ibfk_2` FOREIGN KEY (`IdProducto`) REFERENCES `producto` (`IdProducto`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produccion`
--

LOCK TABLES `produccion` WRITE;
/*!40000 ALTER TABLE `produccion` DISABLE KEYS */;
INSERT INTO `produccion` VALUES (1,'2025-05-01',1,1,120.00,'Producción normal','2025-06-01 22:57:23','2025-06-01 22:57:23'),(2,'2025-05-02',1,2,110.00,'Disminuyó ligeramente','2025-06-01 22:57:23','2025-06-01 22:57:23'),(3,'2025-05-03',1,3,130.00,'Excelente día','2025-06-01 22:57:23','2025-06-01 22:57:23'),(4,'2025-05-04',2,1,90.00,'Temperatura alta','2025-06-01 22:57:23','2025-06-01 22:57:23'),(5,'2025-05-05',2,2,100.00,'Sin novedades','2025-06-01 22:57:23','2025-06-01 22:57:23'),(6,'2025-05-06',2,3,95.00,'Producción constante','2025-06-01 22:57:23','2025-06-01 22:57:23'),(7,'2025-05-07',3,4,50.00,'Carne fresca','2025-06-01 22:57:23','2025-06-01 22:57:23'),(8,'2025-05-08',3,5,48.00,'Carne bien pesada','2025-06-01 22:57:23','2025-06-01 22:57:23'),(9,'2025-05-09',3,6,55.00,'Buen rendimiento','2025-06-01 22:57:23','2025-06-01 22:57:23'),(10,'2025-05-10',4,7,20.00,'Gallinas vendidas','2025-06-01 22:57:23','2025-06-01 22:57:23'),(11,'2025-05-11',4,8,25.00,'Gallinas seleccionadas','2025-06-01 22:57:23','2025-06-01 22:57:23'),(12,'2025-05-12',4,9,18.00,'Gallinas descartadas','2025-06-01 22:57:23','2025-06-01 22:57:23'),(13,'2025-05-13',5,1,140.00,'Producción aumentada','2025-06-01 22:57:23','2025-06-01 22:57:23'),(14,'2025-05-14',5,2,135.00,'Producción estable','2025-06-01 22:57:23','2025-06-01 22:57:23'),(15,'2025-05-15',5,3,150.00,'Muy buen día','2025-06-01 22:57:23','2025-06-01 22:57:23'),(16,'2025-05-16',6,1,100.00,'Sin anomalías','2025-06-01 22:57:23','2025-06-01 22:57:23'),(17,'2025-05-17',6,2,105.00,'Buen clima','2025-06-01 22:57:23','2025-06-01 22:57:23'),(18,'2025-05-18',6,3,115.00,'Aves saludables','2025-06-01 22:57:23','2025-06-01 22:57:23'),(19,'2025-05-19',7,4,60.00,'Procesado temprano','2025-06-01 22:57:23','2025-06-01 22:57:23'),(20,'2025-05-20',7,5,65.00,'Buen peso','2025-06-01 22:57:23','2025-06-01 22:57:23'),(21,'2025-05-21',7,6,58.00,'Buena carne','2025-06-01 22:57:23','2025-06-01 22:57:23'),(22,'2025-05-22',8,7,22.00,'Gallinas listas','2025-06-01 22:57:23','2025-06-01 22:57:23'),(23,'2025-05-23',8,8,27.00,'Buena calidad','2025-06-01 22:57:23','2025-06-01 22:57:23'),(24,'2025-05-24',8,9,20.00,'Gallinas descartadas','2025-06-01 22:57:23','2025-06-01 22:57:23'),(25,'2025-05-25',9,1,95.00,'Menor producción','2025-06-01 22:57:23','2025-06-01 22:57:23'),(26,'2025-05-26',9,2,90.00,'Clima lluvioso','2025-06-01 22:57:23','2025-06-01 22:57:23'),(27,'2025-05-27',9,3,85.00,'Problema leve','2025-06-01 22:57:23','2025-06-01 22:57:23'),(28,'2025-05-28',10,1,110.00,'Producción recuperada','2025-06-01 22:57:23','2025-06-01 22:57:23'),(29,'2025-05-29',10,2,120.00,'Buen promedio','2025-06-01 22:57:23','2025-06-01 22:57:23'),(30,'2025-05-30',10,3,125.00,'Producción alta','2025-06-01 22:57:23','2025-06-01 22:57:23'),(31,'2025-05-31',11,4,52.00,'Peso estándar','2025-06-01 22:57:23','2025-06-01 22:57:23'),(32,'2025-06-01',11,5,49.00,'Menor volumen','2025-06-01 22:57:23','2025-06-01 22:57:23'),(33,'2025-06-02',11,6,54.00,'Buena calidad','2025-06-01 22:57:23','2025-06-01 22:57:23'),(34,'2025-06-03',12,7,24.00,'Gallinas listas','2025-06-01 22:57:23','2025-06-01 22:57:23'),(35,'2025-06-04',12,8,21.00,'Gallinas vendidas','2025-06-01 22:57:23','2025-06-01 22:57:23'),(36,'2025-06-05',12,9,19.00,'Gallinas descartadas','2025-06-01 22:57:23','2025-06-01 22:57:23'),(37,'2025-06-06',13,1,115.00,'Producción esperada','2025-06-01 22:57:23','2025-06-01 22:57:23'),(38,'2025-06-07',13,2,113.00,'Producción controlada','2025-06-01 22:57:23','2025-06-01 22:57:23'),(39,'2025-06-08',13,10,80.00,'Huevos codorniz frescos','2025-06-01 22:57:23','2025-06-01 22:57:23');
/*!40000 ALTER TABLE `produccion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `producto`
--

DROP TABLE IF EXISTS `producto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `producto` (
  `IdProducto` int NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Tipo` enum('Huevos','Carne','Gallina') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Unidad` enum('Kg','Docena','Unidad') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`IdProducto`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `producto`
--

LOCK TABLES `producto` WRITE;
/*!40000 ALTER TABLE `producto` DISABLE KEYS */;
INSERT INTO `producto` VALUES (1,'Huevos AA','Huevos','Docena'),(2,'Huevos A','Huevos','Docena'),(3,'Huevos Orgánicos','Huevos','Docena'),(4,'Carne Pechuga','Carne','Kg'),(5,'Carne Muslo','Carne','Kg'),(6,'Carne Alas','Carne','Kg'),(7,'Gallina Roja','Gallina','Unidad'),(8,'Gallina Negra','Gallina','Unidad'),(9,'Gallina de Descarte','Gallina','Unidad'),(10,'Huevos Codorniz','Huevos','Docena');
/*!40000 ALTER TABLE `producto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sesion_usuario`
--

DROP TABLE IF EXISTS `sesion_usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sesion_usuario` (
  `IdSesion` int NOT NULL AUTO_INCREMENT,
  `IdUsuario` int NOT NULL,
  `IdGranja` int NOT NULL,
  `HoraInicio` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `HoraFin` datetime DEFAULT NULL,
  PRIMARY KEY (`IdSesion`),
  KEY `IdUsuario` (`IdUsuario`),
  KEY `IdGranja` (`IdGranja`),
  CONSTRAINT `sesion_usuario_ibfk_1` FOREIGN KEY (`IdUsuario`) REFERENCES `usuario` (`IdUsuario`),
  CONSTRAINT `sesion_usuario_ibfk_2` FOREIGN KEY (`IdGranja`) REFERENCES `granja` (`IdGranja`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sesion_usuario`
--

LOCK TABLES `sesion_usuario` WRITE;
/*!40000 ALTER TABLE `sesion_usuario` DISABLE KEYS */;
/*!40000 ALTER TABLE `sesion_usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario` (
  `IdUsuario` int NOT NULL AUTO_INCREMENT,
  `NumeroIdentificacion` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `NombreUsuario` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Contraseña` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Email` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rol` enum('admin','cliente','supervisor','veterinario','trabajador') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'cliente',
  PRIMARY KEY (`IdUsuario`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (1,'1234567890','admin_hensys','Admin2025!','admin@hensys.com','admin'),(2,'2345678901','cliente_juan','Cliente123','juanperez@mail.com','cliente'),(3,'3456789012','supervisor_lina','Super2025','lina@hensys.com','supervisor'),(4,'4567890123','vet_carlos','Vet2025!','carlosvet@mail.com','veterinario'),(5,'5678901234','trab_marta','Marta2025*','marta@hensys.com','trabajador');
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario_granja`
--

DROP TABLE IF EXISTS `usuario_granja`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario_granja` (
  `IdUsuario` int NOT NULL,
  `IdGranja` int NOT NULL,
  PRIMARY KEY (`IdUsuario`,`IdGranja`),
  KEY `IdGranja` (`IdGranja`),
  CONSTRAINT `usuario_granja_ibfk_1` FOREIGN KEY (`IdUsuario`) REFERENCES `usuario` (`IdUsuario`),
  CONSTRAINT `usuario_granja_ibfk_2` FOREIGN KEY (`IdGranja`) REFERENCES `granja` (`IdGranja`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario_granja`
--

LOCK TABLES `usuario_granja` WRITE;
/*!40000 ALTER TABLE `usuario_granja` DISABLE KEYS */;
INSERT INTO `usuario_granja` VALUES (1,1),(3,1),(1,2),(2,2),(1,3),(3,3),(5,3),(1,4),(4,4),(1,5),(4,5);
/*!40000 ALTER TABLE `usuario_granja` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vacunacion`
--

DROP TABLE IF EXISTS `vacunacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vacunacion` (
  `IdVacunacion` int NOT NULL AUTO_INCREMENT,
  `TipoVacuna` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CantidadAves` int DEFAULT NULL,
  `Fecha` date DEFAULT NULL,
  `Responsable` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Observaciones` text COLLATE utf8mb4_unicode_ci,
  `id_Galpon` int NOT NULL,
  PRIMARY KEY (`IdVacunacion`),
  KEY `id_Galpon` (`id_Galpon`),
  CONSTRAINT `vacunacion_ibfk_1` FOREIGN KEY (`id_Galpon`) REFERENCES `galpon` (`IdGalpon`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vacunacion`
--

LOCK TABLES `vacunacion` WRITE;
/*!40000 ALTER TABLE `vacunacion` DISABLE KEYS */;
INSERT INTO `vacunacion` VALUES (1,'Newcastle',500,'2025-01-10','Juan Pérez','Primera dosis aplicada con éxito.',1),(2,'Gumboro',450,'2025-01-15','Ana Martínez','Ningún incidente reportado.',2),(3,'Bronquitis Infecciosa',480,'2025-01-20','Luis Rodríguez','Aves tranquilas durante la aplicación.',3),(4,'Viruela Aviar',500,'2025-01-25','María López','Se usó vacuna viva atenuada.',4),(5,'Enfermedad de Marek',470,'2025-02-01','Carlos Gómez','Aplicación en incubadora.',5),(6,'Newcastle',510,'2025-02-05','Carmen Salinas','Refuerzo aplicado.',6),(7,'Gumboro',490,'2025-02-10','Pedro Méndez','Condiciones climáticas ideales.',7),(8,'Bronquitis Infecciosa',500,'2025-02-15','Luisa Ramírez','Sin eventos adversos.',8),(9,'Viruela Aviar',520,'2025-02-20','Jorge Díaz','Buena respuesta inmunológica.',9),(10,'Newcastle',480,'2025-02-25','Nora Suárez','Aplicación subcutánea.',10),(11,'Gumboro',530,'2025-03-01','Andrea Torres','Vacuna almacenada correctamente.',11),(12,'Bronquitis Infecciosa',460,'2025-03-06','Sergio Patiño','No se observaron efectos secundarios.',12),(13,'Viruela Aviar',510,'2025-03-10','Marta Acosta','Uso de jeringas estériles.',13),(14,'Newcastle',495,'2025-03-15','Daniela Castro','Todo el lote fue vacunado.',14),(15,'Gumboro',505,'2025-03-20','Ricardo Peña','Sin bajas tras la vacunación.',15),(16,'Bronquitis Infecciosa',470,'2025-03-25','Laura Rivas','Vacunación durante la mañana.',16),(17,'Viruela Aviar',485,'2025-03-30','Esteban Gil','Seguimiento en 3 días.',17),(18,'Newcastle',500,'2025-04-05','Juliana Nieto','Aplicación oral.',18),(19,'Gumboro',490,'2025-04-10','Camilo Reyes','Condiciones de bioseguridad controladas.',19),(20,'Bronquitis Infecciosa',510,'2025-04-15','Marcela Vega','Vacuna administrada correctamente.',20);
/*!40000 ALTER TABLE `vacunacion` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-02  9:26:05
